import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import requests
import os
from flask import Flask, request

TOKEN = os.getenv("BOT_TOKEN", "8314459008:AAEFzXL8nCUA2pm2V1mQgSCAcbJnVxpdVxc")
bot = telebot.TeleBot(TOKEN)

app = Flask(__name__)

# Asosiy menyu
def main_menu():
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("💱 Kripto kurslari", callback_data="crypto"))
    markup.add(InlineKeyboardButton("💲 Valyuta kurslari", callback_data="currency"))
    return markup

# Orqaga tugmasi
def back_button():
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("◀️ Orqaga", callback_data="back"))
    return markup

# Start komandasi
@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(message.chat.id, "Assalomu alaykum!\nQuyidagi menyudan tanlang:", reply_markup=main_menu())

# Tugmalar ishlash logikasi
@bot.callback_query_handler(func=lambda call: True)
def callback_query(call):
    if call.data == "crypto":
        # Binance API orqali kripto kurslari
        try:
            pairs = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]
            text = "📊 Kripto kurslari:\n"
            for pair in pairs:
                r = requests.get("https://api.binance.com/api/v3/ticker/price", params={"symbol": pair}).json()
                price = float(r["price"])
                text += f"{pair.replace('USDT', '')}: {price:,.2f} USDT\n"
            bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id, text=text, reply_markup=back_button())
        except:
            bot.send_message(call.message.chat.id, "❌ Ma'lumot olishda xatolik!")
    
    elif call.data == "currency":
        # Markaziy bank API orqali valyuta kurslari
        try:
            r = requests.get("https://cbu.uz/oz/arkhiv-kursov-valyut/json/").json()
            usd = next(item for item in r if item["Ccy"] == "USD")["Rate"]
            rub = next(item for item in r if item["Ccy"] == "RUB")["Rate"]
            text = f"💲 Valyuta kurslari:\nUSD: {usd} so'm\nRUB: {rub} so'm"
            bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id, text=text, reply_markup=back_button())
        except:
            bot.send_message(call.message.chat.id, "❌ Valyuta ma'lumotini olishda xatolik!")
    
    elif call.data == "back":
        bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id, text="Asosiy menyu:", reply_markup=main_menu())

# Webhook
@app.route('/' + TOKEN, methods=['POST'])
def getMessage():
    json_str = request.stream.read().decode('UTF-8')
    update = telebot.types.Update.de_json(json_str)
    bot.process_new_updates([update])
    return '!', 200

@app.route("/")
def webhook():
    bot.remove_webhook()
    bot.set_webhook(url=os.getenv("RENDER_URL") + TOKEN)
    return "Webhook o‘rnatildi!", 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
